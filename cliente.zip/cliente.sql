-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-04-2024 a las 17:02:44
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `comercial_foods`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `cod_cliente` int(11) NOT NULL,
  `nombre1` varchar(25) NOT NULL,
  `nombre2` varchar(25) NOT NULL,
  `apellido1` varchar(25) NOT NULL,
  `apellido2` varchar(25) NOT NULL,
  `tipo_documento` enum('CC','CE','NIT','RUT') DEFAULT NULL,
  `no_documento` varchar(25) NOT NULL,
  `sexo` enum('masculino','femenino') DEFAULT NULL,
  `direccion` varchar(50) NOT NULL,
  `ciudad` varchar(20) NOT NULL,
  `fecha_ingreso` date DEFAULT curdate(),
  `edad` int(11) NOT NULL,
  `telefono` varchar(25) NOT NULL,
  `estado_civil` enum('soltero','casado','divorciado','union libre','viudo') DEFAULT NULL,
  `tipo_cliente` enum('detallista','mayorista','empresarial') DEFAULT NULL,
  `activo` varchar(4) NOT NULL DEFAULT 'A',
  `empleado_cod` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`cod_cliente`, `nombre1`, `nombre2`, `apellido1`, `apellido2`, `tipo_documento`, `no_documento`, `sexo`, `direccion`, `ciudad`, `fecha_ingreso`, `edad`, `telefono`, `estado_civil`, `tipo_cliente`, `activo`, `empleado_cod`) VALUES
(1, 'Mario', 'Alexis', 'Aroca', 'Martínez', 'CC', '1122239857', 'masculino', 'CALLE 40 SUR #96-16', 'Bogota', '2024-03-13', 38, '3158097309', 'soltero', 'mayorista', 'A', 3),
(2, 'Jerónimo', '', 'burgos', 'diez', 'CC', '10000459', 'masculino', 'CRA 98 # 58-90', 'Bogota', '2024-03-13', 40, '9015872', 'soltero', '', 'A', 3),
(3, 'Estefanía', 'Tatiana', 'Villegas', 'sierra', 'CC', '1023581203', 'masculino', 'TRV 110 #81-40', 'Bogota', '2024-03-13', 32, '6047599', 'casado', 'mayorista', 'A', 4),
(4, 'Guillermo', 'Mauricio', 'Fernandez', 'Vallejo', 'CC', '125692614', 'masculino', 'CALLE 75 #23SUR-40', 'Barranquilla', '2024-03-13', 43, '7057522', 'soltero', 'mayorista', 'A', 4),
(5, 'Eliana', 'Marcela', 'Ramírez', 'Guerrero', 'NIT', '1222333445', 'femenino', 'Calle 181 #2-45 ', 'Barranquilla', '2024-03-13', 50, '8019053', 'viudo', 'mayorista', 'A', 5),
(6, 'José', 'Gregorio', 'Carmona', 'Guerra', 'CC', '1091562345', 'masculino', 'Cra 3 A # 5-89', 'Barranquilla', '2024-03-13', 29, '3134409180', 'casado', 'detallista', 'A', 5),
(7, 'Marcela', 'Eliana', 'De santis', 'Rodríguez', 'CC', '1091562348', 'femenino', 'calle 9b # 4-20', 'Cali', '2024-03-13', 35, '3108156310', 'union libre', 'mayorista', 'A', 6),
(8, 'Daniela', '', 'Franco', 'Marulanda', 'CC', '1091562312', 'femenino', 'Carrera 56A No. 51 - 81', 'Cali', '2024-03-13', 45, '3212598228', 'union libre', 'mayorista', 'A', 6),
(9, 'Rafael', 'Fabian', 'Cortes', 'Palacio', 'CC', '1091562336', 'masculino', 'Calle 10 No. 9 - 78 Centro', 'Medellin', '2024-03-13', 48, '7586412', 'soltero', 'mayorista', 'A', 7),
(10, 'Camilo', 'Andres', 'Berrios', 'Bermudez', 'CC', '1091562314', 'masculino', 'Calle 24D #5676', 'Medellin', '2024-03-13', 36, '4341235', 'casado', 'mayorista', 'A', 7),
(11, 'Francisco', 'David', 'Arias', 'Toledo', 'CC', '1091562349', 'masculino', 'calle 5b #78c 05', 'Bogota', '2024-03-13', 27, '6018954', 'casado', 'empresarial', 'A', 8),
(12, 'Antonio', 'Giovanny', 'Merizalde', 'Arango', 'CC', '1091562103', 'masculino', 'Calle 23 #54-9', 'Barranquilla', '2024-03-13', 53, '3165846257', 'viudo', 'mayorista', 'A', 8),
(13, 'Karen', 'Rocio', 'Restrepo', 'Acevedo', 'CC', '1091562425', 'femenino', 'cra 7a # 34-89sur', 'Barranquilla', '2024-03-13', 43, '8017936', 'viudo', 'detallista', 'A', 9),
(14, 'David', 'Santiago', 'Lemus', 'Cock', 'NIT', '1112239564', 'masculino', 'cr 5a #20-34 sur', 'Bogota', '2024-03-13', 55, '3412658975', 'soltero', 'mayorista', 'A', 9),
(15, 'Javier', 'Mauricio', 'Santana', 'Casadiegos', 'CC', '1233669874', 'masculino', 'CALLE 27 #58-63', 'Cali', '2024-03-13', 40, '315648301', 'casado', 'mayorista', 'A', 10),
(16, 'Virginia', '', 'Saldarriaga', 'Salamanca', 'CC', '1556998745', 'femenino', 'cll 36 3 1-81 este', 'Medellin', '2024-03-13', 38, '4518992', 'casado', 'detallista', 'A', 10);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`cod_cliente`),
  ADD KEY `nombre1` (`nombre1`,`apellido1`),
  ADD KEY `empleado_cod` (`empleado_cod`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `cod_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`empleado_cod`) REFERENCES `empleado` (`cod_empleado`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
